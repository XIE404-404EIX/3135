<?php
include_once("databaseconn.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <title> Family Mart</title>
        <style>
          * {
  box-sizing: border-box;
}
 
html,
body {
  width: 100%;
  height: 100%;
  margin: 0;
  background-color: black;
  font-family: 'Roboto', sans-serif;
}
          
          .shopping-cart {
          width: 750px;
          height: 423px;
          margin: 80px auto;
          background: white;
          box-shadow: 1px 2px 3px 0px rgba(0,0,0,0.10);
          border-radius: 6px;
 
          display: flex;
          flex-direction: column;}
          
         .title {
          height: 60px;
          border-bottom: 1px solid gray;
          padding: 20px 30px;
          color: #5E6977;
          font-size: 18px;
          font-weight: 400;
        }
 
        
 
        .is-active {
          animation-name: animate;
          animation-duration: .8s;
          animation-iteration-count: 1;
          animation-timing-function: steps(28);
          animation-fill-mode: forwards;
    }
 
        @keyframes animate {
  0%   { background-position: left;  }
  50%  { background-position: right; }
  100% { background-position: right; }
}
 

@media (max-width: 800px) {
  .shopping-cart {
    width: 100%;
    height: auto;
    overflow: hidden;
  }
  
  h2 { color: solid gray;
  }
  
  </style>
    </head>
  <div class="shopping-cart">
      <div class="title">
          Shopping Cart
      </div>
      <div>
          <main>
              <aside>
              <h2>Cartegories</h2>
              <nav>
                  <ul>
                      <li>
                        <a href="DrinkList.php">Drink</a>
                      </li>
                      <li>
                        <a href="Snack.php">Snack</a>
                      </li>
                      <li>
                        <a href="BakedGoods.php">Baked</a>
                      </li>
                  </ul>
                  
              </nav>
              </aside>
        <section>
            <!-- display a table of products -->
            <h2>Table</h2>
            <table>
                <tbody>
                    <tr>
                        <th>Number</th>
                        <th>Name</th>
                        <th class="right">Price</th>
                        <th>&nbsp;</th>
                    </tr>
                    <td>1</td>
                    <td>Coca</td>
                    <td class="right">2.50</td>
                    <td><form action="." method="post">
                    <input type="hidden" name="action"
                           value="delete_product">
                    <input type="hidden" name="product_id"
                           value="<?php echo $product['productID']; ?>">
                    <input type="hidden" name="category_id"
                           value="<?php echo $product['categoryID']; ?>">
                    <input type="submit" value="Delete">
                </form></td>
                    </tr>
                </tbody>
            </table>
        </section>
          </main>
      </div>
      
          </div>
      
  </div> 
</html>