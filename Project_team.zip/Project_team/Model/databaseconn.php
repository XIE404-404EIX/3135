<?php

$dbserverName = "localhost";
$dbuserName = "family_mart_admin";
$dbPassword = "pa55word";
$dbName = "family_mart";

$connection = mysqli_connect($dbserverName, $dbuserName, $dbPassword, $dbName);

?>