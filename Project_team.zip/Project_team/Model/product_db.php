<?php
class productDB{
    public static function getBakedGoods() {
        $db = Database::getDB();
        $query = 'SELECT productCode, productName, listPrice
                  FROM products WHERE categoryID=3;';
                  
        try {
            $statement = $db->prepare($query);
            $statement->execute();
            
            $rows = $statement->fetchAll();
            $statement->closeCursor();
            
            $product = [];
            foreach ($rows as $row) {
                $product[] = new Product($row['productCode'], $row['productName'], $row['listPrice']);
            }
            return $product;

        } catch (PDOException $e) {
            Database::displayError($e->getMessage());
        }
    }
    
    


    
   
}
?>