<?php
class User {
     

    public function __construct(
        $firstName,
        $lastName,
        $email,
        $phoneNumber,
        $userName,
        $password
    ) { }
    
    public function getfirstName(){
        return $this->firstName;
    }

    public function setfirstName(string $value) {
        $this->firstName = $value;
    }
    
    public function getlastName(){
        return $this->lastName;
    }
   
    public function setlastName(string $value) {
        $this->lastName = $value;
    }
    
    public function getemail(){
        return $this->email;
    }

    public function setemail(string $value) {
        $this->email = $value;
    }
    
    public function getphoneNumber(){
        return $this->phoneNumber;
    }
    
    public function setphoneNumber(string $value) {
        $this->phoneNumber = $value;
    }
    
    public function getuserName(){
        return $this->userName;
    }

    public function setuserName(string $value) {
        $this->userName = $value;
    }
    
    public function getpassword(){
        return $this->password;
    }
    
    
    public function setpassword(string $value) {
        $this->password = $value;
    }
   
}
?>