<html>
    <head>
        <h1 style="text-align:center">Snack Product</h1>
    </head>
    <body>
        <form>
        <input type="text"></input>
        <button>Search</button>
        <br>
        </form>
        
        <label>Product Name</label>
        <Image></Image>
    </body>
</html>