<?php
require_once ('Model/database.php');
require_once ('Model/registration.php');
require_once ('Model/registration_db.php');
require_once ('Model/login.php');
require_once ('Model/login_db.php');

$action = filter_input(INPUT_POST, 'action');



if ($action == NULL) {
    $action = 'default';
}






    
switch ($action) {
    
    case 'default':
        include('WelcomePage.php');
        break;
    
    case 'register':
        //add data into user table
       

        $firstName = filter_input(INPUT_POST, 'firstName');
        $lastName = filter_input(INPUT_POST, 'lastName');
        $email = filter_input(INPUT_POST,'email');
        $phoneNumber = filter_input(INPUT_POST,'phoneNumber');
        $userName = filter_input(INPUT_POST, 'userName');
        $password = filter_input(INPUT_POST,'password');
        
        if ($firstName == NULL || $lastName == NULL || $email == NULL || $phoneNumber == NULL || $userName == NULL || $password == NULL) 
        {echo "Error for now";
            include("WelcomePage.php");
        }
        else{ 
            $current_user = new User($firstName, $lastName, $userName, $phoneNumber, $email, $password);
            $userId = RegistrationDB::insertRegistration($firstName, $lastName, $userName, $phoneNumber, $email, $password);
            header("Location: .?action=default");
        }
        break;
        
}




?>
