<html>
    <head>
        <h1 style="text-align:center">Family Mart</h1>
    </head>
    <body>
        <form action="index.php" method="post" id="register">
            <input type="hidden" id="action" name="action" value="register">
            <label>First Name:</label>
            <input type="text" method="post" name="firstName"></input>
            <br>
            
            <label>Last Name:</label>
            <input type="text" method="post" name="lastName"></input>
            <br>
            
            <label>Email Address:</label>
            <input type="text" method="post" name="email"></input>
            <br>
            
            <label>Phone:</label>
            <input type="text" method="post" name="phoneNumber"></input>
            <br>
            
            <label>User Name:</label>
            <input type="text" method="post" name="userName"></input>
            <br>
            
            <label>Password:</label>
            <input type="text" method="post" name="password"></input>
            <br>
            <input type="submit" value="Submit"></input>
            
        </form>
        
        
       <a href="WelcomePage.php"><button>Cancel</button></a>
        
    </body>
</html>