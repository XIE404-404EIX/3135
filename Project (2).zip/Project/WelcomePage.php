
<!DOCTYPE html>
<html>
    <head>
        <h1 style="text-align:center">Family Mart</h1>
    </head>
    <body>
        <h3 style="text-align:center"><a href="RegistrationPage.php">Registration</a></h3>
        <h3 style="text-align:center"><a href="LoginPage.php">Login</a></h3>
    </body>
</html>