<?php
require_once ('Model/database.php');
require_once ('Model/registration.php');
require_once ('Model/registration_db.php');
require_once ('Model/login.php');
require_once ('Model/login_db.php');

$action = filter_input(INPUT_POST, 'action');



if ($action == NULL) {
    $action = 'default';
}






    
switch ($action) {
    
    case 'default':
        include('WelcomePage.php');
        break;
    
    case 'register':
        //add data into user table
       

        $firstName = filter_input(INPUT_POST, 'firstName');
        $lastName = filter_input(INPUT_POST, 'lastName');
        $email = filter_input(INPUT_POST,'email');
        $phoneNumber = filter_input(INPUT_POST,'phoneNumber');
        $userName = filter_input(INPUT_POST, 'userName');
        $password = filter_input(INPUT_POST,'password');
        
        
        if ($firstName == NULL || $lastName == NULL || $email == NULL || $phoneNumber == NULL || $userName == NULL || $password == NULL) 
        {echo "Error for now";
            include("WelcomePage.php");
        }
        else{ 
            $userId = RegistrationDB::insertRegistration($firstName, $lastName, $userName, $phoneNumber, $email, $password);
            header("Location: .?action=default");
        }
        break;
        
    case 'login':
        $loginUserName = filter_input(INPUT_POST, 'login_userName');
        $loginPassword = filter_input(INPUT_POST, 'login_password');
        
        if ($loginUserName == NULL || $loginPassword == NULL){
            echo("Please enter username/password");
            include("LoginPage.php");
        }else{
            
        
        $login_user = loginDB::getLogin($loginUserName, $loginPassword);
        if(loginDB::getLogin($loginUserName, $loginPassword)){
                $lifetime = 60*60/24/14;
                session_set_cookie_params($lifetime, '/');
                session_start();
                include("CategoryList.php");
            }
        else{
                echo("Invalid username or password");
                header("Location: .?action=login");
            }
        }
        break;
        
}




?>
