<!DOCTYPE html>
<html>
    <head>
        <h1 style="text-align:center">Family Mart</h1>
    </head>
    <body>
        <form action="index.php" method="post" id="login">
            <input type="hidden" id="action" name="action" value="login">
            <label>User Name:</label>
            <input type="text" method="post" name="login_userName"></input>
            <br>
        
            <label>Password:</label>
            <input type="password" method="post" name="login_password"></input>
            <br>
        
        <button type="submit" value="submit">Login</button>
        </form>
        
        <a href="WelcomePage.php"><button>Cancel</button></a>
    </body>
</html>