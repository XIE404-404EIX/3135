<?php
class loginDB {
    public static function getLogin($userName, $password) {
        $db = Database::getDB();
        $query = 'SELECT userName, password
        FROM users';
        
       try {
           $statement = $db->prepare($query);
           $statement->bindValue(':userName', $userName->getuserName());
           $statement->bindValue(':password', $password->getpassword());
           $statement->execute();
           $statement->closeCursor();

          
       } catch (PDOException $e) {
           Database::displayError($e->getMessage());
       }
    }

    
}
?>