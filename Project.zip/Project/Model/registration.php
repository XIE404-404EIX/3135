<?php
class User {
     

    public function __construct(
         string $userID,
         string $firstName,
         string $lastName,
         string $userName,
         string $phoneNumber,
         string $email,
         string $password
    ) { }

   

   

  

    public function setID(int $value) {
        $this->userID = $value;
    }

    

    public function setfirstName(string $value) {
        $this->firstName = $value;
    }

   

    public function setlastName(string $value) {
        $this->lastName = $value;
    }
    
    

    public function setuserName(string $value) {
        $this->userName = $value;
    }

    
    public function setphoneNumber(string $value) {
        $this->phoneNumber = $value;
    }

    

    public function setemail(string $value) {
        $this->email = $value;
    }

    
      public function setpassword(string $value) {
        $this->password = $value;
    }
   
}
?>