<?php
class RegistrationDB {
    public static function insertRegistration($current_user) {
        $db = Database::getDB();
        $query = 'INSERT INTO users (firstName, lastName, userName, phoneNumber, email, password)
        VALUES
                    (:firstName, :lastname, :userName, :phoneNumber,
                     :email, :password';
       try {
           $statement = $db->prepare($query);
           $statement->bindValue(':firstName', $firstName->setfirstName());
           $statement->bindValue(':lastName', $lastName->setlastName());
           $statement->bindValue(':userName', $userName->setuserName());
           $statement->bindValue(':phoneNumber', $phoneNumber->setphoneNumber());
           $statement->bindValue(':email', $email->setemail());
           $statement->bindValue(':password', $password->setpassword());
           $statement->execute();
           $statement->closeCursor();

          
       } catch (PDOException $e) {
           Database::displayError($e->getMessage());
       }
    }

    
}

?>