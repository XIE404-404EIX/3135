<?php
class RegistrationDB {
    public static function insertRegistration($userID) {
        $db = Database::getDB();
        $query = 'INSERT INTO users (userID, firstName, lastName, userName, phoneNumber, email, password)
        VALUES
                    (:userID, :firstName, :lastname, :userName, :phoneNumber,
                     :email, :password';
       try {
           $statement = $db->prepare($query);
           $statement->bindValue(':userID', $userID->setID());
           $statement->bindValue(':firstName', $firstName->setfirstName());
           $statement->bindValue(':lastName', $lastName->setlastName());
           $statement->bindValue(':userName', $userName->setuserName());
           $statement->bindValue(':phoneNumber', $phoneNumber->setphoneNumber());
           $statement->bindValue(':email', $email->setemail());
           $statement->bindValue(':password', $password->setpassword());
           $statement->execute();
           $statement->closeCursor();

          
       } catch (PDOException $e) {
           Database::displayError($e->getMessage());
       }
    }

    
}

?>