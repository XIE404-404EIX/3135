<!DOCTYPE html>
<html>
    <head>
        <h1 style="text-align:center">Family Mart</h1>
    </head>
    <body>
        <h3 style="text-align:center"><a href="Registration.php">Registration</a></h3>
        <h3 style="text-align:center"><a href="Login.php">Login</a></h3>
    </body>
</html>