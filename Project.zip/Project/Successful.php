<html>
    <head>
        <h1> Congratulation!</h1>
    </head>
    <body>
        <h3>You are successfully register an account.</h3>
        <a href="WelcomePage.php"><button>Back</button></a>
    </body>
</html>