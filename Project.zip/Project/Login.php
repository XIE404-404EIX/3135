<!DOCTYPE html>
<html>
    <head>
        <h1 style="text-align:center">Family Mart</h1>
    </head>
    <body>
        <label>User Name:</label>
        <input type="text"></input>
        <br>
        
        <label>Password:</label>
        <input type="text"></input>
        <br>
        
        <button id="Login" type="submit">Login</button>
        <a href="WelcomePage.php"><button>Cancel</button></a>
    </body>
</html>