<html>
    <head>
        <h1 style="text-align:center">Baked Goods</h1>
    </head>
    <body>
        <input type="text"></input>
        <button>Search</button>
        <br>
        <label>Product Name</label>
        <Image></Image>
    </body>
</html>