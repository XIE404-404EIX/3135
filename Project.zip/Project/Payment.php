<html>
    <head>
        <h1 style="text-align:center">
            Checkout
        </h1>
    </head>
    <body>
        <label>Card number:</label>
        <input type="text"></input>
        <br>
        
        <label>First Name:</label>
        <input type="text"></input>
        <br>
        
        <label>Last Name:</label>
        <input type="text"></input>
        <br>
        
        <label>Address:</label>
        <input type="text"></input>
        <br>
        
        <label>Phone:</label>
        <input type="text"></input>
        <br>
        
        <label>Email Address:</label>
        <input type="text"></input>
        <br>
        
        <button>Checkout</button>
        <input type="button" value="Back to the cart" onclick="history.back()">
    </body>
</html>