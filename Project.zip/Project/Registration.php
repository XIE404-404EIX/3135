<html>
    <head>
        <h1 style="text-align:center">Family Mart</h1>
    </head>
    <body>
        <label>First Name:</label>
        <input type="text"></input>
        <br>
        
        <label>Last Name:</label>
        <input type="text"></input>
        <br>
        
        <label>Email Address:</label>
        <input type="text"></input>
        <br>
        
        <label>Phone:</label>
        <input type="text"></input>
        <br>
        
        <label>User Name:</label>
        <input type="text"></input>
        <br>
        
        <label>Password:</label>
        <input type="text"></input>
        <br>
        
        <button>Register</button>
        <a href="WelcomePage.php"><button>Cancel</button></a>
    </body>
</html>