<!DOCTYPE html>
<html>
    <head>
        <h1 style="text-align:center">Category</h1>
    </head>
    <body>
        <h3 style="text-align:center"><a href="DrinkList.php">Drink</a></h3>
        <h3 style="text-align:center"><a href="Snack.php">Snack</a></h3>
        <h3 style="text-align:center"><a href="BakedGoods.php">Baked Goods</a></h3>
    </body>
</html>