<html>
    <head>
        
    </head>
    <body>
        <label>Product ID:</label>
        <br>
        
        <label>Product Name:</label>
        <br>
        
        <image src="Image/Coke.jpg" style="width:200px;height:200px;"></image>
        <p>
            This is Product Description.
        </p>
        <label>Price:</label>
        
        <br>
        <button>Add to Wishlist</button>
        <button>Add to Cart</button>
        <a href="DrinkList.php"><button>Back to Drink List</button></a>
    </body>
</html>