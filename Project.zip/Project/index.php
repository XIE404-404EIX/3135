<?php
require_once ('Model/registration.php');
require_once ('Model/registration_db.php');
require_once ('Model/login.php');
require_once ('Model/login_db.php');
require_once ('Model/database.php');

$action = filter_input(INPUT_POST, 'action');
if ($action == NULL) {
    $action = filter_input(INPUT_GET, 'action');
    if ($action == NULL) {
        $action = 'register';
    }
}

switch ($action) {
    case 'register':
        // get current category
        $userID = filter_input(INPUT_GET, 'userID');
        if ($userID == NULL || $userID === FALSE) {
            echo "Error for now"
        }                

        // get categories and products
        $current_user = RegistrationDB::insertRegistration($userID);
        

        // display view
        include('WelcomePage.php');
        break;
    case 'view_product':
        $categories = CategoryDB::getCategories();

        // get product data
        $product_id = filter_input(INPUT_GET, 'product_id', 
                FILTER_VALIDATE_INT);
        $product = ProductDB::getProduct($product_id);
        
        // display product
        include('product_view.php');
        break;
}




include('WelcomePage.php');
?>

