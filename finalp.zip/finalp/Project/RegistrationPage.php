<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: black;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: blue;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}


a {
  color: dodgerblue;
}


.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
    </head>
    
    <body>
        <form action="index.php" method="post" id="register">
            <div class="container">
                    <h1>Register</h1>
                    
           
            <label for="firstName">First Name:</label>
            <input type="text" placeholder="Enter first name" method="post" name="firstName" required></input>
            <br>
            
            <label for="lastName">Last Name:</label>
            <input type="text" placeholder="Enter last name" method="post" name="lastName" required></input>
            <br>
            
            <label for="email">Email Address:</label>
            <input type="text" placeholder="Enter email" method="post" name="email" required></input>
            <br>
            
            <label for="phoneNumber">Phone:</label>
            <input type="text" placeholder="Enter phone number" method="post" name="phoneNumber" required></input>
            <br>
            
            <label for="userName">User Name:</label>
            <input type="text" placeholder="Enter username" method="post" name="userName" required></input>
            <br>
            
            <label for="password">Password:</label>
            <input type="text" placeholder="Enter password"  method="post" name="password" required></input>
            <br>
             <button type="submit" class="registerbtn">Register</button>
      
  </div>
            <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
         <div class="container signin">
            <p>Already have an account? <a href="#">Sign in</a>.</p>
          </div>
          
        </form>
        
        
       <a href="WelcomePage.php"><button>Cancel</button></a>
        
    </body>
</html>