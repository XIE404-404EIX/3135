<?php

class loginUser {
     public function __construct(
         string $userName,
         string $password
    ) { }

    public function getuserName() {
        return $this->userName;
    }

    public function getpassword() {
        return $this->password;
    }
    
   
}
?>