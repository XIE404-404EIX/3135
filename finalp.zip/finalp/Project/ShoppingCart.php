<?php

?>

<!DOCTYPE html>
<html>

<!-- the head section -->
<head>
    <title>Family Mart</title>
    <link rel="stylesheet" href="main.css" />
</head>

<!-- the body section -->
<body>
<header><h1>Cart</h1></header>
<main>
    
    <table>
        <form action="insert.php" method="post"></form>
        <tr>
            <th>Name</th>
            <th>&nbsp;</th>
        </tr>
        <tr>
            <td>Coca Cola</td>
            <td>
                <form action="delete_product.php" method="post">
                    <input type="submit" value="Delete">
                    
                </form>
            </td>
        </tr>
        
        <tr>
            <td>Doritos</td>
            <td>
                <form action="delete_product.php" method="post">
                    <input type="submit" value="Delete">
                    
                </form>
            </td>
        </tr>
         
        <tr>
            <td>Muffin</td>
            <td>
                <form action="delete_product.php" method="post">
                    <input type="submit" value="Delete">
                    
                </form>
            </td>
        </tr>
        
        </form><!-- add code for the rest of the table here -->
    
    </table>
    
    <input type="button" value="Checkout">
 
   
    

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Family Mart, Inc.</p>
    </footer>
</body>
</html>