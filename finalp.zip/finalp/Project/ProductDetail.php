<html>
    <head>
        
    </head>
    <body>
        <form>
        <label>Product ID:</label>
        <br>
        
        <label>Product Name:</label>
        <br>
        
        <image src="Image/Coke.jpg" style="width:200px;height:200px;"></image>
        <p>
            This is Product Description.
        </p>
        <label>Price:</label>
        
        <br>
        <input type="submit" value="Add to Wishlist">
        <input type="submit" value="Add to Cart">
        </form>
        
        <a href="DrinkList.php"><button>Back to Drink List</button></a>
    </body>
</html>