<?php
class loginDB {
    public static function getLogin($loginUserName, $loginPassword) {
        $db = Database::getDB();
        $query = 'Select * FROM users WHERE userName=:login_userName AND password=:login_password';
        
        try {
           $statement = $db->prepare($query);
           $statement->bindValue(':login_userName', $loginUserName);
           $statement->bindValue(':login_password', $loginPassword);
           $statement->execute();
           $statement->closeCursor();
           
           if('SELECT password FROM users WHERE userName=:login_userName'){
               return TRUE;
           }
           
           

          
        } catch (PDOException $e) {
           Database::displayError($e->getMessage());
        }
       
    }

    
}
?>