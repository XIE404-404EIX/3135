<!DOCTYPE html>
<html>
<style>
    body, html {
  height: 100%;
  margin: 0;
}

.backgroundImage {
  background-image: url('Image/Categorylist.jpg');
  height: 100%;
  background-position: center;
  background-size: cover;
  position: relative;
  color: white;
  font-family: "Courier New", Courier, monospace;
  font-size: 25px;
}

a:link {
  color: red;
  background-color: transparent;
  text-decoration: none;
}
a:hover {
  color: white;
  background-color: transparent;
  text-decoration: underline;
}
</style>    
    <div class = "backgroundImage">
    <head>
        <h1 style="text-align:left; color:red">Category List</h1>
    </head>

    <body>
        <h3 style="text-align:left"><a href="DrinkList.php">Drink</a></h3>
        <h3 style="text-align:left"><a href="Snack.php">Snack</a></h3>
        <h3 style="text-align:left"><a href="BakedGoods.php">Baked Goods</a></h3>
    </body>
    </div>
</html>