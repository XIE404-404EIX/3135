<?php
class RegistrationDB {
    public static function insertRegistration($firstName, $lastName, $email, $phoneNumber, $userName, $password) {
        $db = Database::getDB();
        $query = 'INSERT INTO users 
                    (firstName, lastName, userName, phoneNumber, email, password)
                 VALUES
                    (:firstName, :lastName, :userName, :phoneNumber,
                     :email, :password)';
       try {
           $statement = $db->prepare($query);
           $statement->bindValue(':firstName', $firstName);
           $statement->bindValue(':lastName', $lastName);
           $statement->bindValue(':email', $email);
           $statement->bindValue(':phoneNumber', $phoneNumber);
           $statement->bindValue(':userName', $userName);
           $statement->bindValue(':password', $password);
           $statement->execute();
           $statement->closeCursor();

       } catch (PDOException $e) {
           Database::displayError($e->getMessage());
       }
    }

    
}

?>