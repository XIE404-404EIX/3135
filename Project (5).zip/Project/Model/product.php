<?php
class Product {

    public function __construct(
        string $code,
        string $name,
        float $price
    ) { }

    

    public function getCode() {
        return $this->code;
    }

    public function setCode(string $value) {
        $this->code = $value;
    }

    public function getName() {
        return $this->name;
    }

    public function setName(string $value) {
        $this->name = $value;
    }
    
    

    public function getPrice() {
        return $this->price;
    }


    public function setPrice(float $value) {
        $this->price = $value;
    }

    

    public function getImageFilename() {
        $image_filename = $this->code . '_m.png';
        return $image_filename;
    }

    public function getImagePath(string $app_path) {
        $image_path = $app_path . 'images/' . $this->getImageFilename();
        return $image_path;
    }

    public function getImageAltText() {
        $image_alt = 'Image: ' . $this->getImageFilename();
        return $image_alt;
    }
}
?>