<?php

namespace cart {
    


// Add an item to the cart
function add_item(&$cart, string $productKey, array $row) {
    
            $item = [
                'name' => $row['name'],
                'cost' => $row['cost'],
            ]; 
            $cart[$productKeykey] = $item;
    }
}    


?>