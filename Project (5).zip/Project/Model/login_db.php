<?php
class loginDB {
    public static function getLogin($loginUserName, $loginPassword) {
        $db = Database::getDB();
        $query = 'Select password FROM users WHERE  userName=:login_userName';
        
        try {
           $statement = $db->prepare($query);
           $statement->bindValue(':login_userName', $loginUserName);
           $statement->execute();
           $row = $statement->fetch();
           $frow = $row[0];
           $statement->closeCursor();
                      
           if($frow['userName'] == $loginPassword){
               return TRUE;
           }

          
        } catch (PDOException $e) {
           Database::displayError($e->getMessage());
        }
        
    }

    
}
?>
