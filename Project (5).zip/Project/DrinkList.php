<?php 

include_once('Model/databaseconn.php');

?>
<html>
<style>
    body, html {
  height: 100%;
  margin: 0;
}

.backgroundImage {
  background-image: url('Image/List.png');
  height: 100%;
  background-position: center;
  background-size: cover;
  position: relative;
  color: white;
  font-family: "Courier New", Courier, monospace;
  font-size: 25px;
}

.searchBar{
    position:  absolute;
    top:       70px;
    left:      762px; 
    height:    20px;
}

.searchButton{
    position: absolute;
    top:      70px;
    left:     950px; 
    height:   20px;
}

.PN{
    position: absolute;
    top: 10%;
    left: 40%;
    color: white;
}

.DL{
    position: absolute;
    top: 15%;
    left: 39%;
    color: white;
}

.GTS{
    position: absolute;
    top: 75%;
    left: 10%;
    color: white;
    font-size: 100%;
}

.GTBG{
    position: absolute;
    top: 80%;
    left: 10%;
    color: white;
    font-size: 100%;
}

a:link {
  color: white;
  background-color: transparent;
  text-decoration: none;
}
a:hover {
  color: red;
  background-color: transparent;
  text-decoration: underline;
}
</style>
    <div class = "backgroundImage">
    <head>
        <h1 style="text-align:center">Drinks</h1>
    </head>
    <form action="index.php" method="post" id="search">
        <input type="text" method="post"class = "searchBar" id="action" name="search" value="search"></input>
        <button type="submit" class = "searchButton">Search</button>
        <br>
        </form>
    <body>
        
         <table align="center" border="1px" style="width:600px; line-height:40px;">
        <tr>
            <th colspan="4"><h2>Products</h2></th>
        </tr>
        
        <t>
            <th> Product Name </th>
            <th> Price </th>
            <th> Product Code </th>
            <th> Options </th>
        </t>
        
         <?php 
        $sql = "SELECT * FROM products WHERE categoryID=1;";
        $result = mysqli_query($connection, $sql);
        $resultCheck = mysqli_num_rows($result);
        
        if ($resultCheck > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
    ?>
        
        <tr>   
            <td><?php echo $row['productName']?></td> 
            <td><?php echo $row['listPrice']?> </td>
            <td><?php echo $row['productCode']?></td>
            <td><button class = "ATC">Add to cart</button>  <button class = "ATWL">Add to wishlist</button></td>
        </tr>
        
        
        <?php
            }}
            ?>
        </table>    
        <label class = "GTS"><a href="Snack.php">Snack List</a></label>
        <label class = "GTBG"><a href="BakedGoods.php">Baked Goods List</a></label>
    </body>
    </div>
</html>