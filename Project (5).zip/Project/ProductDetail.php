<?php 

include_once('Model/dbh.php');

?>
<html>
    <?php 
        $sql = "SELECT productName FROM products WHERE categoryID=2;";
        $result = mysqli_query($conn, $sql);
        $resultCheck = mysqli_num_rows($result);
        
        if ($resultCheck > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
    ?>
    
    <tr>
        <td><?php echo $row['productName'] ?></td><button>Add to cart</button><br>
    </tr>
    <?php
            }}
    ?>        
</html>





